// ─────────────────────────────────────────────────────────────────────────────
// FreeFollowers — background.js  (Phase 2 — sends data to Flask)
// ─────────────────────────────────────────────────────────────────────────────

// !! CHANGE THIS to your actual server URL when deployed on Hetzner
// For local testing use: 'http://localhost:5000'
const SERVER_URL = 'http://localhost:5000';

let SESSION_ID = null;

async function getOrCreateSessionId() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['session_id'], (result) => {
      if (result.session_id) {
        SESSION_ID = result.session_id;
        resolve(SESSION_ID);
      } else {
        const newId = Array.from(crypto.getRandomValues(new Uint8Array(8)))
          .map(b => b.toString(16).padStart(2, '0'))
          .join('');
        chrome.storage.local.set({ session_id: newId });
        SESSION_ID = newId;
        console.log('[FreeFollowers] New session ID:', SESSION_ID);
        resolve(SESSION_ID);
      }
    });
  });
}

const graph = { nodes: {}, edges: {} };

function getRootDomain(urlString) {
  try {
    const hostname = new URL(urlString).hostname;
    const parts = hostname.split('.');
    if (parts.length >= 2) return parts.slice(-2).join('.');
    return hostname;
  } catch (e) { return null; }
}

function addNode(domain, type) {
  if (!domain) return;
  if (!graph.nodes[domain]) {
    graph.nodes[domain] = { id: domain, label: domain, type: type, count: 1 };
    console.log(`[FreeFollowers] New node: ${type.toUpperCase()} — ${domain}`);
  } else {
    graph.nodes[domain].count++;
  }
}

function addEdge(source, target, cookieName = null) {
  if (!source || !target || source === target) return;
  const edgeId = `${source}||${target}`;
  if (!graph.edges[edgeId]) {
    graph.edges[edgeId] = {
      id: edgeId, source: source, target: target,
      cookies: cookieName ? [cookieName] : [], count: 1
    };
    console.log(`[FreeFollowers] New edge: ${source} → ${target}`);
  } else {
    graph.edges[edgeId].count++;
    if (cookieName && !graph.edges[edgeId].cookies.includes(cookieName)) {
      graph.edges[edgeId].cookies.push(cookieName);
    }
  }
}

function startRequestListener() {
  chrome.webRequest.onBeforeSendHeaders.addListener(
    (details) => {
      if (details.tabId === -1) return;
      if (details.url.startsWith('chrome-extension://')) return;
      if (details.url.startsWith('moz-extension://')) return;
      const sourceDomain = details.initiator ? getRootDomain(details.initiator) : null;
      const targetDomain = getRootDomain(details.url);
      if (!sourceDomain || !targetDomain) return;
      addNode(sourceDomain, 'site');
      if (sourceDomain !== targetDomain) {
        addNode(targetDomain, 'tracker');
        addEdge(sourceDomain, targetDomain);
      }
      if (details.requestHeaders) {
        for (const header of details.requestHeaders) {
          if (header.name.toLowerCase() === 'cookie') {
            const cookieNames = header.value
              .split(';').map(c => c.trim().split('=')[0].trim()).filter(n => n.length > 0);
            for (const cookieName of cookieNames) addEdge(sourceDomain, targetDomain, cookieName);
          }
        }
      }
    },
    { urls: ['<all_urls>'] },
    ['requestHeaders']
  );
  console.log('[FreeFollowers] Request listener active.');
}

async function readExistingCookies() {
  chrome.cookies.getAll({}, (cookies) => {
    console.log(`[FreeFollowers] Found ${cookies.length} existing cookies.`);
    for (const cookie of cookies) {
      const domain = cookie.domain.replace(/^\./, '');
      const rootDomain = getRootDomain('https://' + domain);
      if (rootDomain) addNode(rootDomain, 'tracker');
    }
  });
}

function getGraphAsJson() {
  return {
    session_id: SESSION_ID,
    nodes:      Object.values(graph.nodes),
    edges:      Object.values(graph.edges),
    timestamp:  new Date().toISOString()
  };
}

// ── SEND TO FLASK ─────────────────────────────────────────────────────────────
async function sendToServer() {
  const graphData = getGraphAsJson();
  if (graphData.nodes.length === 0) return;
  try {
    const response = await fetch(`${SERVER_URL}/api/graph`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(graphData)
    });
    if (response.ok) {
      console.log(`[FreeFollowers] Sent — ${graphData.nodes.length} nodes, ${graphData.edges.length} edges`);
    } else {
      console.warn('[FreeFollowers] Server error:', response.status);
    }
  } catch (err) {
    console.warn('[FreeFollowers] Could not reach server:', err.message);
  }
}

// ── CLICK ICON → OPEN INSTALL/GRAPH PAGE ─────────────────────────────────
chrome.action.onClicked.addListener(() => {
  // Go to install page with session ID — it detects extension and redirects to graph
  const url = `${SERVER_URL}/install?session=${SESSION_ID}`;
  chrome.tabs.create({ url: url });
  console.log(`[FreeFollowers] Opening: ${url}`);
});

self.getGraph = () => { const g = getGraphAsJson(); console.log(JSON.stringify(g, null, 2)); return g; };

// ── INIT ──────────────────────────────────────────────────────────────────────
async function init() {
  console.log('[FreeFollowers] Starting...');
  await getOrCreateSessionId();
  startRequestListener();
  await readExistingCookies();
  setInterval(sendToServer, 3000);
  console.log(`[FreeFollowers] Graph will be at: ${SERVER_URL}/graph/${SESSION_ID}`);
}

init();
